#ifndef D64WRITER_H_
#define D64WRITER_H_

void usbtool_prg_load_and_run(void);

/* from write_disk.h */
void write_disk_d64(void);


#endif /* D64WRITER_H_ */
