/*
 * usbtool.h
 *
 *  Created on: 27.01.2012
 *      Author: skoe
 */

#ifndef USBTOOL_H_
#define USBTOOL_H_

void usbtool_prg_load_and_run(void);


#endif /* USBTOOL_H_ */
