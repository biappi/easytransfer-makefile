/*
 * autoinit.h
 *
 *  Created on: 31.03.2012
 *      Author: skoe
 */

#ifndef AUTOINIT_H_
#define AUTOINIT_H_

void autoInit(void);


#endif /* AUTOINIT_H_ */
