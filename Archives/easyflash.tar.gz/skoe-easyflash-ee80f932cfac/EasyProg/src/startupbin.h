

#ifndef STARTUPBIN_H_
#define STARTUPBIN_H_

extern uint8_t* startUpStart;
extern uint8_t* startUpEnd;

#endif /* STARTUPBIN_H_ */
