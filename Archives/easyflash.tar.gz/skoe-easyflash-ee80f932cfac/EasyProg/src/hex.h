/*
 * hex.h
 *
 *  Created on: 04.06.2009
 *      Author: skoe
 */

#ifndef HEX_H_
#define HEX_H_

void hexViewer(void);

#endif /* HEX_H_ */
